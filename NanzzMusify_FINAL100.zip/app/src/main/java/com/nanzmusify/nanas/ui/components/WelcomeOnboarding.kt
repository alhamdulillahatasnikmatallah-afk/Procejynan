/*
 * Copyright (C) 2026 Nanas
 * SPDX-License-Identifier: GPL-3.0-only
 */
package com.nanzmusify.nanas.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nanzmusify.nanas.data.settings.SettingsRepository
import com.nanzmusify.nanas.ui.theme.NanzMusifyBackground
import com.nanzmusify.nanas.ui.theme.NanzMusifyCrimson
import com.nanzmusify.nanas.ui.theme.NanzMusifyHairline
import com.nanzmusify.nanas.ui.theme.NanzMusifySurface
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextMuted
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextPrimary
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextSecondary
import kotlinx.coroutines.launch

@Composable
fun WelcomeOnboarding(settingsRepo: SettingsRepository, onFinished: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var ageText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxSize().background(NanzMusifyBackground).padding(horizontal = 28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Selamat Datang", style = MaterialTheme.typography.headlineMedium, color = NanzMusifyTextPrimary, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Nanzz Musify", style = MaterialTheme.typography.titleMedium, color = NanzMusifyCrimson)
        Spacer(Modifier.height(8.dp))
        Text("Isi data singkat sebelum mulai. Hanya untuk usia 10 tahun ke atas.", style = MaterialTheme.typography.bodyMedium, color = NanzMusifyTextSecondary, textAlign = TextAlign.Center)
        Spacer(Modifier.height(28.dp))
        Text("Namamu siapa?", style = MaterialTheme.typography.labelLarge, color = NanzMusifyTextMuted, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(name, { name = it; error = null }, placeholder = { Text("Nama panggilan") }, singleLine = true, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), colors = fc())
        Spacer(Modifier.height(16.dp))
        Text("Umur berapa?", style = MaterialTheme.typography.labelLarge, color = NanzMusifyTextMuted, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(ageText, { ageText = it.filter { c -> c.isDigit() }.take(3); error = null }, placeholder = { Text("Contoh: 15") }, singleLine = true, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done), colors = fc())
        if (error != null) { Spacer(Modifier.height(12.dp)); Text(error!!, style = MaterialTheme.typography.bodySmall, color = NanzMusifyCrimson, textAlign = TextAlign.Center) }
        Spacer(Modifier.height(28.dp))
        Button(
            onClick = {
                val n = name.trim(); val age = ageText.toIntOrNull()
                when {
                    n.isBlank() -> error = "Nama wajib diisi."
                    age == null -> error = "Umur wajib diisi angka."
                    age < 10 -> error = "Maaf, usia di bawah 10 tahun tidak diizinkan."
                    age > 120 -> error = "Umur tidak valid."
                    else -> scope.launch { settingsRepo.completeOnboarding(n, age); onFinished() }
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(50),
            colors = ButtonDefaults.buttonColors(containerColor = NanzMusifyCrimson, contentColor = NanzMusifyBackground),
        ) { Text("Lanjut ke Nanzz Musify", fontWeight = FontWeight.SemiBold) }
    }
}
@Composable private fun fc() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = NanzMusifyTextPrimary, unfocusedTextColor = NanzMusifyTextPrimary,
    focusedBorderColor = NanzMusifyCrimson, unfocusedBorderColor = NanzMusifyHairline, cursorColor = NanzMusifyCrimson,
    focusedContainerColor = NanzMusifySurface, unfocusedContainerColor = NanzMusifySurface,
    focusedPlaceholderColor = NanzMusifyTextMuted, unfocusedPlaceholderColor = NanzMusifyTextMuted,
)
