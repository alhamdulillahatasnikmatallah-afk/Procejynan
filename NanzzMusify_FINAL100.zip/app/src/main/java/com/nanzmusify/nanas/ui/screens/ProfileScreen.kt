/*
 * Copyright (C) 2026 Nanas
 * SPDX-License-Identifier: GPL-3.0-only
 */
package com.nanzmusify.nanas.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nanzmusify.nanas.ui.theme.NanzMusifyBackground
import com.nanzmusify.nanas.ui.theme.NanzMusifyCrimson
import com.nanzmusify.nanas.ui.theme.NanzMusifyHairline
import com.nanzmusify.nanas.ui.theme.NanzMusifyRadius
import com.nanzmusify.nanas.ui.theme.NanzMusifySurface
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextMuted
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextPrimary
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextSecondary

private const val DEVELOPER_WHATSAPP_NUMBER = "6287881592763"
private const val CHANNEL_NANZ_GOVERNMENT = "https://whatsapp.com/channel/0029VbCsS2r2phHIV3O0nO1a"
private const val CHANNEL_NOWAYY = "https://whatsapp.com/channel/0029VbDJEfVHbFV04NMawV2U"

@Composable
fun ProfileScreen(onOpenFullSettings: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var bugDescription by rememberSaveable { mutableStateOf("") }
    var reporterName by rememberSaveable { mutableStateOf("") }
    val canSend = bugDescription.isNotBlank() && reporterName.isNotBlank()
    fun openUrl(url: String) { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } }
    fun sendToWhatsApp() {
        val message = "Laporan Bug Nanzz Musify\n\nNama: ${reporterName.trim()}\nBug: ${bugDescription.trim()}"
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$DEVELOPER_WHATSAPP_NUMBER?text=${Uri.encode(message)}"))) }
    }
    Column(modifier.fillMaxSize().background(NanzMusifyBackground).verticalScroll(rememberScrollState())
        .windowInsetsPadding(WindowInsets.navigationBars).padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("Nanzz Musify", style = MaterialTheme.typography.headlineSmall, color = NanzMusifyTextPrimary, fontWeight = FontWeight.Bold)
                Text("Profil & Info", style = MaterialTheme.typography.bodySmall, color = NanzMusifyTextMuted)
            }
            IconButton(onClick = onOpenFullSettings) { Icon(Icons.Filled.Settings, contentDescription = "Pengaturan", tint = NanzMusifyTextSecondary) }
        }
        ProfileCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(CircleShape).background(NanzMusifyCrimson.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Construction, null, tint = NanzMusifyCrimson, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.width(12.dp))
                Text("Dalam tahap pengembangan", style = MaterialTheme.typography.titleMedium, color = NanzMusifyTextPrimary, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(14.dp))
            Text("APP INI DALAM TAHAP PENGEMBANGAN OLEH NANZ DAN TIM REKANYA. JIKA ANDA MENEMUKAN BUG / MASALAH YANG ANDA ALAMI, ANDA BISA MENGHUBUNGI DEVELOPER UNTUK MEMPERBAIKI BUG. SEBELUM TERHUBUNG KE DEVELOPER, ANDA WAJIB MENGISI FORMULIR DI BAWAH INI!",
                style = MaterialTheme.typography.bodyMedium, color = NanzMusifyTextSecondary, textAlign = TextAlign.Start)
            Spacer(Modifier.height(10.dp))
            Text("Nomor Developer: 878-8159-2763", style = MaterialTheme.typography.labelLarge, color = NanzMusifyCrimson, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(16.dp))
        ProfileCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Info, null, tint = NanzMusifyCrimson, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp))
                Text("Tentang aplikasi", style = MaterialTheme.typography.titleSmall, color = NanzMusifyTextPrimary, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(12.dp))
            Text("Nanzz Musify adalah aplikasi pemutar musik modern yang dirancang agar pengalaman mendengarkan lebih nyaman, cepat, dan elegan. Dikembangkan oleh Nanz bersama tim rekannya.",
                style = MaterialTheme.typography.bodyMedium, color = NanzMusifyTextSecondary)
        }
        Spacer(Modifier.height(16.dp))
        ProfileCard {
            Text("Info aplikasi", style = MaterialTheme.typography.titleSmall, color = NanzMusifyTextPrimary, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            InfoRow("Nama", "Nanzz Musify"); InfoRow("Versi", "1.0"); InfoRow("Developer", "Nanz")
            InfoRow("Tim Project", "Nowayy & rekan"); InfoRow("Status", "Beta / Pengembangan")
        }
        Spacer(Modifier.height(16.dp))
        ProfileCard {
            Text("Join saluran WhatsApp", style = MaterialTheme.typography.titleSmall, color = NanzMusifyTextPrimary, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(14.dp))
            ChannelButton("Saluran Nanz Goverment", "Selaku developer") { openUrl(CHANNEL_NANZ_GOVERNMENT) }
            Spacer(Modifier.height(10.dp))
            ChannelButton("Saluran Nowayy", "Tim project") { openUrl(CHANNEL_NOWAYY) }
        }
        Spacer(Modifier.height(16.dp))
        ProfileCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.BugReport, null, tint = NanzMusifyCrimson, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp))
                Text("Laporkan bug ke developer", style = MaterialTheme.typography.titleSmall, color = NanzMusifyTextPrimary, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(6.dp))
            Text("Isi formulir ini sebelum menghubungi developer.", style = MaterialTheme.typography.bodySmall, color = NanzMusifyTextMuted)
            Spacer(Modifier.height(16.dp))
            Text("Bug / masalah yang dialami:", style = MaterialTheme.typography.labelMedium, color = NanzMusifyTextMuted)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(bugDescription, { bugDescription = it }, placeholder = { Text("Contoh: lagu berhenti sendiri saat...") },
                minLines = 3, maxLines = 6, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), colors = profileFieldColors())
            Spacer(Modifier.height(14.dp))
            Text("Nama Anda:", style = MaterialTheme.typography.labelMedium, color = NanzMusifyTextMuted)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(reporterName, { reporterName = it }, placeholder = { Text("Nama Anda") }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), colors = profileFieldColors())
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(50))
                .background(if (canSend) NanzMusifyCrimson else NanzMusifySurface)
                .border(1.dp, if (canSend) Color.Transparent else NanzMusifyHairline, RoundedCornerShape(50))
                .clickable(enabled = canSend) { sendToWhatsApp() }.padding(vertical = 14.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Send, null, tint = if (canSend) NanzMusifyBackground else NanzMusifyTextMuted, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Kirim ke WhatsApp Developer", style = MaterialTheme.typography.labelLarge,
                    color = if (canSend) NanzMusifyBackground else NanzMusifyTextMuted, fontWeight = FontWeight.SemiBold)
            }
            if (!canSend) {
                Spacer(Modifier.height(8.dp))
                Text("Isi kedua kolom di atas dulu sebelum mengirim.", style = MaterialTheme.typography.labelSmall, color = NanzMusifyTextMuted)
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}

@Composable private fun ProfileCard(content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(NanzMusifyRadius.lg)).background(NanzMusifySurface)
        .border(1.dp, NanzMusifyHairline, RoundedCornerShape(NanzMusifyRadius.lg)).padding(18.dp)) { content() }
}
@Composable private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = NanzMusifyTextMuted)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = NanzMusifyTextPrimary)
    }
}
@Composable private fun ChannelButton(title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(NanzMusifyRadius.sm)).background(NanzMusifyBackground.copy(alpha = 0.5f))
        .border(1.dp, NanzMusifyHairline, RoundedCornerShape(NanzMusifyRadius.sm)).clickable(onClick = onClick)
        .padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = NanzMusifyTextPrimary, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = NanzMusifyTextMuted)
        }
        Icon(Icons.Outlined.OpenInNew, null, tint = NanzMusifyTextSecondary, modifier = Modifier.size(18.dp))
    }
}
@Composable private fun profileFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = NanzMusifyTextPrimary, unfocusedTextColor = NanzMusifyTextPrimary,
    focusedBorderColor = NanzMusifyCrimson, unfocusedBorderColor = NanzMusifyHairline, cursorColor = NanzMusifyCrimson,
    focusedPlaceholderColor = NanzMusifyTextMuted, unfocusedPlaceholderColor = NanzMusifyTextMuted)
