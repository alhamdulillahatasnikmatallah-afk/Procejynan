/*
 * Copyright (C) 2026 Nanas
 * SPDX-License-Identifier: GPL-3.0-only
 */
package com.nanzmusify.nanas.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nanzmusify.nanas.data.settings.SettingsRepository
import com.nanzmusify.nanas.ui.theme.NanzMusifyBackground
import com.nanzmusify.nanas.ui.theme.NanzMusifyCrimson
import com.nanzmusify.nanas.ui.theme.NanzMusifySurface
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextPrimary
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextSecondary
import kotlinx.coroutines.launch

private data class TourStep(val title: String, val body: String)

@Composable
fun ToolsTourOverlay(
    settingsRepo: SettingsRepository,
    onFinished: () -> Unit,
) {
    val steps = remember {
        listOf(
            TourStep("Home & Dashboard", "Geser cover 16:9 Hits Indonesia. Tap Mood Booster untuk mulai putar suasana."),
            TourStep("Search & Suara", "Cari lagu, artis, album. Tekan ikon mikrofon untuk mencari dengan suara."),
            TourStep("Library", "Kelola Playlist, Album, dan Artis. Buat playlist baru dari tombol +."),
            TourStep("Offline", "Unduh lagu lalu putar tanpa kuota. Cek ukuran MB di setiap file."),
            TourStep("Disukai & Profil", "Simpan favorit di Disukai. Di Profil ada info app, channel WA, dan form laporan bug."),
        )
    }
    var index by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    val step = steps[index]

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.72f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .background(NanzMusifySurface, RoundedCornerShape(20.dp))
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Tour Tools", style = MaterialTheme.typography.labelLarge, color = NanzMusifyCrimson)
            Spacer(Modifier.height(8.dp))
            Text(step.title, style = MaterialTheme.typography.titleLarge, color = NanzMusifyTextPrimary, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            Text(step.body, style = MaterialTheme.typography.bodyMedium, color = NanzMusifyTextSecondary, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text("${index + 1} / ${steps.size}", style = MaterialTheme.typography.labelSmall, color = NanzMusifyTextSecondary)
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = {
                    scope.launch {
                        settingsRepo.setToolsTourDone(true)
                        onFinished()
                    }
                }) { Text("Lewati", color = NanzMusifyTextSecondary) }
                Button(
                    onClick = {
                        if (index < steps.lastIndex) index++
                        else scope.launch {
                            settingsRepo.setToolsTourDone(true)
                            onFinished()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NanzMusifyCrimson, contentColor = NanzMusifyBackground),
                    shape = RoundedCornerShape(50),
                ) {
                    Text(if (index < steps.lastIndex) "Lanjut" else "Selesai")
                }
            }
        }
    }
}
