/*
 * Copyright (C) 2026 Nanas
 * SPDX-License-Identifier: GPL-3.0-only
 */
package com.nanzmusify.nanas.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nanzmusify.nanas.R
import com.nanzmusify.nanas.data.model.NanzMusifyTrack
import com.nanzmusify.nanas.player.PlayerManager
import com.nanzmusify.nanas.ui.theme.NanzMusifyCrimson
import com.nanzmusify.nanas.ui.theme.NanzMusifyElevated
import com.nanzmusify.nanas.ui.theme.NanzMusifyHairline
import com.nanzmusify.nanas.ui.theme.NanzMusifyMotion
import com.nanzmusify.nanas.ui.theme.NanzMusifyRadius
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextPrimary
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextSecondary
import com.nanzmusify.nanas.ui.theme.nanzmusifyChromeEnter
import com.nanzmusify.nanas.ui.theme.nanzmusifyChromeExit
import com.nanzmusify.nanas.ui.theme.nanzmusifyTween

private val MiniShape = RoundedCornerShape(NanzMusifyRadius.md)

@Composable
fun MiniPlayerBar(
    track: NanzMusifyTrack?, isPlaying: Boolean, isBuffering: Boolean,
    player: PlayerManager, visible: Boolean,
    onToggle: () -> Unit, onNext: () -> Unit, onOpen: () -> Unit,
    modifier: Modifier = Modifier,
) {
    AnimatedVisibility(visible = visible && track != null, enter = nanzmusifyChromeEnter(), exit = nanzmusifyChromeExit(), modifier = modifier) {
        if (track == null) return@AnimatedVisibility
        val pos by player.position.collectAsStateWithLifecycle()
        val progress = if (pos.durationMs > 0) pos.positionMs.toFloat() / pos.durationMs else 0f
        val p by animateFloatAsState(progress.coerceIn(0f, 1f), nanzmusifyTween(NanzMusifyMotion.deliberate), label = "mini_prog")
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
                .clip(MiniShape).background(NanzMusifyElevated).border(1.dp, NanzMusifyHairline, MiniShape)
                .clickable(onClick = onOpen),
        ) {
            LinearProgressIndicator(
                progress = { if (isBuffering) 0f else p },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = NanzMusifyCrimson, trackColor = androidx.compose.ui.graphics.Color.Transparent, strokeCap = StrokeCap.Butt,
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Artwork(url = track.thumbnailUrl, title = track.title, size = 48.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(track.title, style = MaterialTheme.typography.titleSmall, color = NanzMusifyTextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(track.artist.ifBlank { stringResource(R.string.common_youtube_music) }, style = MaterialTheme.typography.labelSmall, color = NanzMusifyTextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                NanzMusifyMiniPlay(isPlaying = isPlaying, onClick = onToggle, size = 42.dp)
                IconButton(onClick = onNext, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Filled.SkipNext, contentDescription = stringResource(R.string.np_next), tint = NanzMusifyTextPrimary, modifier = Modifier.size(26.dp))
                }
            }
        }
    }
}
