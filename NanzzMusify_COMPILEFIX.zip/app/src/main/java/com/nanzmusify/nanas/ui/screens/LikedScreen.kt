/*
 * Copyright (C) 2026 Nanas
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package com.nanzmusify.nanas.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nanzmusify.nanas.R
import com.nanzmusify.nanas.data.model.NanzMusifyTrack
import com.nanzmusify.nanas.player.PlayerUiState
import com.nanzmusify.nanas.ui.components.Artwork
import com.nanzmusify.nanas.ui.components.TrackRow
import com.nanzmusify.nanas.ui.theme.NanzMusifyBackground
import com.nanzmusify.nanas.ui.theme.NanzMusifyCrimson
import com.nanzmusify.nanas.ui.theme.NanzMusifySurface
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextMuted
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextPrimary
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextSecondary
import com.nanzmusify.nanas.ui.vm.LibraryViewModel

/**
 * Layar "Liked Songs" tersendiri (bukan sub-tab Library lagi) — sesuai desain
 * referensi: judul besar + lencana hati di kanan atas, daftar lagu disukai,
 * dan status kosong berupa hati bulat di tengah.
 */
@Composable
fun LikedScreen(
    vm: LibraryViewModel,
    playerState: PlayerUiState,
    onPlayQueue: (List<NanzMusifyTrack>, Int) -> Unit,
    onTrackMore: (NanzMusifyTrack) -> Unit,
    onLike: (NanzMusifyTrack) -> Unit,
    likedIds: Set<String>,
    downloadedIds: Set<String>,
    modifier: Modifier = Modifier,
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val liked = state.liked
    var likedFilter by remember { mutableStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NanzMusifyBackground),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "♡  Disukai",
                style = MaterialTheme.typography.headlineMedium,
                color = NanzMusifyTextPrimary,
                modifier = Modifier.weight(1f),
            )
            Box(
                modifier = Modifier
                    .background(NanzMusifySurface)
                    .padding(10.dp),
            ) {
                Icon(Icons.Filled.Favorite, contentDescription = null, tint = NanzMusifyCrimson)
            }
        }

        // Filter chips (mockup visual)
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            listOf("Semua", "Lagu", "Album", "Artis").forEachIndexed { i, label ->
                val selected = likedFilter == i
                Text(
                    label,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (selected) NanzMusifyBackground else NanzMusifyTextSecondary,
                    modifier = Modifier
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(50))
                        .background(if (selected) NanzMusifyTextPrimary else NanzMusifySurface)
                        .clickable { likedFilter = i }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
        }
        Spacer(Modifier.height(8.dp))

        if (liked.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                    .background(NanzMusifySurface)
                    .border(1.dp, com.nanzmusify.nanas.ui.theme.NanzMusifyHairline, androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                    .padding(vertical = 40.dp, horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    modifier = Modifier
                        .background(NanzMusifySurface)
                        .padding(20.dp),
                ) {
                    Icon(
                        Icons.Filled.Favorite,
                        contentDescription = null,
                        tint = NanzMusifyTextSecondary,
                        modifier = Modifier.height(32.dp),
                    )
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    stringResource(R.string.liked_empty_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = NanzMusifyTextPrimary,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    stringResource(R.string.liked_empty_body),
                    style = MaterialTheme.typography.bodyMedium,
                    color = NanzMusifyTextMuted,
                    textAlign = TextAlign.Center,
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 96.dp),
            ) {
                when (likedFilter) {
                    2 -> {
                        val albums = liked.groupBy { it.album.ifBlank { "Tanpa Album" } }
                        albums.entries.sortedBy { it.key }.forEach { (name, tracks) ->
                            item(key = "alb_$name") {
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 20.dp, vertical = 6.dp)
                                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                                        .background(NanzMusifySurface)
                                        .clickable { onPlayQueue(tracks, 0) }
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Artwork(url = tracks.first().thumbnailUrl, title = name, size = 52.dp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(name, style = MaterialTheme.typography.titleSmall, color = NanzMusifyTextPrimary, maxLines = 1)
                                        Text("${tracks.size} lagu", style = MaterialTheme.typography.bodySmall, color = NanzMusifyTextMuted)
                                    }
                                }
                            }
                        }
                    }
                    3 -> {
                        val artists = liked.groupBy { it.artist.ifBlank { "Unknown" } }
                        artists.entries.sortedBy { it.key }.forEach { (name, tracks) ->
                            item(key = "art_$name") {
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 20.dp, vertical = 6.dp)
                                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                                        .background(NanzMusifySurface)
                                        .clickable { onPlayQueue(tracks, 0) }
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Artwork(url = tracks.first().thumbnailUrl, title = name, size = 52.dp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(name, style = MaterialTheme.typography.titleSmall, color = NanzMusifyTextPrimary, maxLines = 1)
                                        Text("${tracks.size} lagu", style = MaterialTheme.typography.bodySmall, color = NanzMusifyTextMuted)
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        itemsIndexed(liked, key = { _, tr -> tr.videoId }) { index, track ->
                            TrackRow(
                                track = track,
                                isActive = playerState.currentTrack?.videoId == track.videoId,
                                isPlaying = playerState.isPlaying,
                                isLiked = likedIds.contains(track.videoId),
                                isDownloaded = downloadedIds.contains(track.videoId),
                                index = index,
                                onPlay = { onPlayQueue(liked, index) },
                                onLike = { onLike(track) },
                                onMore = { onTrackMore(track) },
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}
