/*
 * Copyright (C) 2026 Nanas
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package com.nanzmusify.nanas.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nanzmusify.nanas.R
import com.nanzmusify.nanas.data.db.PlaylistEntity
import com.nanzmusify.nanas.data.model.NanzMusifyTrack
import com.nanzmusify.nanas.player.PlayerUiState
import com.nanzmusify.nanas.ui.components.Artwork
import com.nanzmusify.nanas.ui.components.SectionRule
import com.nanzmusify.nanas.ui.components.TrackRow
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextSecondary
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextPrimary
import com.nanzmusify.nanas.ui.theme.NanzMusifyLine
import com.nanzmusify.nanas.ui.theme.NanzMusifyElevated
import com.nanzmusify.nanas.ui.theme.NanzMusifySurface
import com.nanzmusify.nanas.ui.theme.NanzMusifyBackground
import com.nanzmusify.nanas.ui.theme.NanzMusifyCrimson
import com.nanzmusify.nanas.ui.theme.NanzMusifyHairline
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextMuted
import com.nanzmusify.nanas.ui.vm.LibraryTab
import com.nanzmusify.nanas.ui.vm.LibraryViewModel

@Composable
fun LibraryScreen(
    vm: LibraryViewModel,
    playerState: PlayerUiState,
    onPlayQueue: (List<NanzMusifyTrack>, Int) -> Unit,
    onTrackMore: (NanzMusifyTrack) -> Unit,
    onLike: (NanzMusifyTrack) -> Unit,
    onOpenPlaylist: (Long, String) -> Unit,
    likedIds: Set<String>,
    downloadedIds: Set<String>,
    modifier: Modifier = Modifier,
    initialTab: Int = 0,
) {
    val state by vm.state.collectAsStateWithLifecycle()
    var showNewPlaylist by remember { mutableStateOf(false) }
    var playlistToDelete by remember { mutableStateOf<PlaylistEntity?>(null) }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        LibraryTab.entries.getOrNull(initialTab)?.let(vm::selectTab)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NanzMusifyBackground),
    ) {
        // ---- Header (mockup) ----
        Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    text = "Library",
                    style = MaterialTheme.typography.headlineMedium,
                    color = NanzMusifyTextPrimary,
                )
                Icon(
                    imageVector = Icons.Filled.Settings,
                    contentDescription = null,
                    tint = NanzMusifyTextSecondary,
                    modifier = Modifier.size(22.dp),
                )
            }
            Spacer(Modifier.height(14.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(LibraryTab.entries.toList(), key = { it.name }) { tab ->
                    val selected = state.tab == tab
                    Box(
                        modifier = Modifier
                            .border(1.dp, if (selected) NanzMusifyCrimson else NanzMusifyLine)
                            .background(
                                if (selected) NanzMusifyCrimson.copy(alpha = 0.18f)
                                else NanzMusifySurface.copy(alpha = 0.25f),
                            )
                            .clickable { vm.selectTab(tab) }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                    ) {
                        Text(
                            when (tab) {
                                LibraryTab.FAVORIT -> stringResource(R.string.tab_favorite)
                                LibraryTab.PLAYLIST -> "Playlist"
                                LibraryTab.ALBUM -> "Album"
                                LibraryTab.ARTIS -> "Artis"
                                LibraryTab.RIWAYAT -> stringResource(R.string.tab_history)
                                LibraryTab.OFFLINE -> stringResource(R.string.tab_offline)
                                LibraryTab.LOCAL -> stringResource(R.string.tab_local)
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = if (selected) NanzMusifyTextPrimary else NanzMusifyTextSecondary,
                        )
                    }
                }
            }
        }

        // ---- Isi tab ----
        if (state.tab == LibraryTab.LOCAL) {
            // Tab LOKAL punya LazyColumn sendiri (daftar panjang + gerbang izin)
            LocalMusicContent(
                playerState = playerState,
                onPlayQueue = onPlayQueue,
                onTrackMore = onTrackMore,
                onLike = onLike,
                likedIds = likedIds,
                downloadedIds = downloadedIds,
                modifier = Modifier.fillMaxSize(),
            )
            return@Column
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 96.dp),
        ) {
            when (state.tab) {
                LibraryTab.LOCAL -> { /* tidak tercapai — ditangani di atas */ }

                LibraryTab.ALBUM -> {
                    val albums = (state.liked + state.history).groupBy { it.album.ifBlank { "Tanpa Album" } }
                    if (albums.isEmpty()) {
                        item { EmptyNote("Belum ada album", "Putar atau sukai lagu agar album muncul di sini.") }
                    } else {
                        albums.entries.sortedBy { it.key }.forEach { (name, tracks) ->
                            item(key = "alb_$name") {
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 20.dp, vertical = 6.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(NanzMusifySurface)
                                        .clickable { onPlayQueue(tracks, 0) }
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Artwork(url = tracks.firstOrNull()?.thumbnailUrl.orEmpty(), title = name, size = 52.dp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(name, style = MaterialTheme.typography.titleSmall, color = NanzMusifyTextPrimary, maxLines = 1)
                                        Text("${tracks.size} lagu", style = MaterialTheme.typography.bodySmall, color = NanzMusifyTextMuted)
                                    }
                                }
                            }
                        }
                    }
                }

                LibraryTab.ARTIS -> {
                    val artists = (state.liked + state.history).groupBy { it.artist.ifBlank { "Unknown" } }
                    if (artists.isEmpty()) {
                        item { EmptyNote("Belum ada artis", "Putar atau sukai lagu agar artis muncul di sini.") }
                    } else {
                        artists.entries.sortedBy { it.key }.forEach { (name, tracks) ->
                            item(key = "art_$name") {
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 20.dp, vertical = 6.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(NanzMusifySurface)
                                        .clickable { onPlayQueue(tracks, 0) }
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Artwork(url = tracks.firstOrNull()?.thumbnailUrl.orEmpty(), title = name, size = 52.dp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(name, style = MaterialTheme.typography.titleSmall, color = NanzMusifyTextPrimary, maxLines = 1)
                                        Text("${tracks.size} lagu", style = MaterialTheme.typography.bodySmall, color = NanzMusifyTextMuted)
                                    }
                                }
                            }
                        }
                    }
                }

                LibraryTab.FAVORIT -> {
                    if (state.liked.isEmpty()) {
                        item { EmptyNote(stringResource(R.string.library_fav_empty_title), stringResource(R.string.library_fav_empty_body)) }
                    } else {
                        item {
                            PlayAllBar(
                                label = stringResource(R.string.library_play_all_fav),
                                onClick = { onPlayQueue(state.liked, 0) },
                            )
                        }
                        itemsIndexed(state.liked, key = { _, t -> t.videoId }) { index, track ->
                            TrackRow(
                                track = track,
                                isActive = playerState.currentTrack?.videoId == track.videoId,
                                isPlaying = playerState.isPlaying,
                                isLiked = true,
                                isDownloaded = downloadedIds.contains(track.videoId),
                                index = index,
                                onPlay = { onPlayQueue(state.liked, index) },
                                onLike = { onLike(track) },
                                onMore = { onTrackMore(track) },
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                            )
                        }
                    }
                }

                LibraryTab.PLAYLIST -> {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 8.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(NanzMusifySurface)
                                .border(1.dp, NanzMusifyHairline, RoundedCornerShape(16.dp))
                                .clickable { showNewPlaylist = true }
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(NanzMusifyCrimson.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = null, tint = NanzMusifyCrimson, modifier = Modifier.size(26.dp))
                            }
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text("Playlist Baru", style = MaterialTheme.typography.titleSmall, color = NanzMusifyTextPrimary)
                                Text("Buat playlist favoritmu", style = MaterialTheme.typography.bodySmall, color = NanzMusifyTextMuted)
                            }
                        }
                    }
                    if (state.playlists.isEmpty()) {
                        item { EmptyNote(stringResource(R.string.library_pl_empty_title), stringResource(R.string.library_pl_empty_body)) }
                    } else {
                        items(state.playlists, key = { it.playlist.id }) { stats ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 20.dp, vertical = 6.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(NanzMusifySurface)
                                    .border(1.dp, NanzMusifyHairline, RoundedCornerShape(14.dp))
                                    .clickable { onOpenPlaylist(stats.playlist.id, stats.playlist.name) }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Artwork(
                                    url = stats.coverUrl.orEmpty(),
                                    title = stats.playlist.name,
                                    size = 52.dp,
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        stats.playlist.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = NanzMusifyTextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        stringResource(R.string.playlist_track_count, stats.itemCount),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = NanzMusifyTextSecondary,
                                    )
                                }
                                IconButton(onClick = { playlistToDelete = stats.playlist }) {
                                    Icon(
                                        Icons.Filled.DeleteOutline,
                                        contentDescription = stringResource(R.string.action_delete),
                                        tint = NanzMusifyTextMuted,
                                    )
                                }
                            }
                        }
                    }
                }

                LibraryTab.RIWAYAT -> {
                    if (state.history.isEmpty()) {
                        item { EmptyNote(stringResource(R.string.history_empty_title), stringResource(R.string.history_empty_body)) }
                    } else {
                        item {
                            PlayAllBar(
                                label = stringResource(R.string.history_replay),
                                secondary = stringResource(R.string.history_clear),
                                onClick = { onPlayQueue(state.history, 0) },
                                onSecondary = { vm.clearHistory() },
                            )
                        }
                        itemsIndexed(state.history, key = { _, t -> t.videoId }) { index, track ->
                            TrackRow(
                                track = track,
                                isActive = playerState.currentTrack?.videoId == track.videoId,
                                isPlaying = playerState.isPlaying,
                                isLiked = likedIds.contains(track.videoId),
                                isDownloaded = downloadedIds.contains(track.videoId),
                                index = index,
                                onPlay = { onPlayQueue(state.history, index) },
                                onLike = { onLike(track) },
                                onMore = { onTrackMore(track) },
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                            )
                        }
                    }
                }

                LibraryTab.OFFLINE -> {
                    val offlineTracks = state.downloads
                        .filter { it.state == "DONE" }
                        .map { d -> NanzMusifyTrack(d.videoId, d.title, d.artist, d.album, d.durationSec, d.thumbnailUrl) }

                    item {
                        OfflineSummary(
                            downloads = state.downloads,
                            onPlayDownloads = {
                                if (offlineTracks.isNotEmpty()) onPlayQueue(offlineTracks, 0)
                            },
                        )
                        SectionRule(label = stringResource(R.string.offline_queue_hint))
                    }

                    if (offlineTracks.isEmpty()) {
                        item { EmptyNote(stringResource(R.string.offline_storage), stringResource(R.string.downloads_empty)) }
                    } else {
                        itemsIndexed(offlineTracks, key = { _, t -> t.videoId }) { index, track ->
                            TrackRow(
                                track = track,
                                isActive = playerState.currentTrack?.videoId == track.videoId,
                                isPlaying = playerState.isPlaying,
                                isLiked = likedIds.contains(track.videoId),
                                isDownloaded = true,
                                index = index,
                                onPlay = { onPlayQueue(offlineTracks, index) },
                                onLike = { onLike(track) },
                                onMore = { onTrackMore(track) },
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                            )
                        }
                    }
                }
            }
        }
    }

    if (showNewPlaylist) {
        NewPlaylistDialog(
            onCreate = {
                vm.createPlaylist(it)
                showNewPlaylist = false
            },
            onDismiss = { showNewPlaylist = false },
        )
    }

    playlistToDelete?.let { pl ->
        AlertDialog(
            onDismissRequest = { playlistToDelete = null },
            containerColor = NanzMusifyElevated,
            title = { Text(stringResource(R.string.delete_playlist_title), style = MaterialTheme.typography.labelMedium, color = NanzMusifyCrimson) },
            text = {
                Text(
                    stringResource(R.string.delete_playlist_body, pl.name),
                    style = MaterialTheme.typography.bodyMedium,
                    color = NanzMusifyTextSecondary,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.deletePlaylist(pl)
                    playlistToDelete = null
                }) { Text(stringResource(R.string.action_delete), style = MaterialTheme.typography.labelMedium, color = NanzMusifyCrimson) }
            },
            dismissButton = {
                TextButton(onClick = { playlistToDelete = null }) {
                    Text(stringResource(R.string.action_cancel), style = MaterialTheme.typography.labelMedium, color = NanzMusifyTextSecondary)
                }
            },
        )
    }
}

@Composable
internal fun EmptyNote(title: String, body: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 24.dp)
            .border(1.dp, NanzMusifyLine)
            .padding(20.dp),
    ) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = NanzMusifyTextPrimary)
        Spacer(Modifier.height(6.dp))
        Text(body, style = MaterialTheme.typography.bodySmall, color = NanzMusifyTextMuted)
    }
}

@Composable
private fun PlayAllBar(
    label: String,
    secondary: String? = null,
    onClick: () -> Unit,
    onSecondary: (() -> Unit)? = null,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .border(1.dp, NanzMusifyCrimson)
                .background(NanzMusifyCrimson.copy(alpha = 0.15f))
                .clickable(onClick = onClick)
                .padding(12.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = NanzMusifyTextPrimary)
        }
        if (secondary != null) {
            Box(
                modifier = Modifier
                    .border(1.dp, NanzMusifyLine)
                    .background(NanzMusifySurface.copy(alpha = 0.3f))
                    .clickable { onSecondary?.invoke() }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(secondary, style = MaterialTheme.typography.labelMedium, color = NanzMusifyTextSecondary)
            }
        }
    }
}

@Composable
private fun OfflineSummary(
    downloads: List<com.nanzmusify.nanas.data.db.DownloadEntity>,
    onPlayDownloads: () -> Unit,
) {
    val done = downloads.count { it.state == "DONE" }
    val active = downloads.count { it.state == "QUEUED" || it.state == "DOWNLOADING" }
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp)
            .border(1.dp, NanzMusifyLine)
            .background(NanzMusifySurface.copy(alpha = 0.3f))
            .padding(16.dp),
    ) {
        Text(stringResource(R.string.offline_storage), style = MaterialTheme.typography.labelMedium, color = NanzMusifyCrimson)
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(R.string.offline_summary, done, active),
            style = MaterialTheme.typography.bodySmall,
            color = NanzMusifyTextSecondary,
        )
        Spacer(Modifier.height(12.dp))
        if (done > 0) {
            Box(
                modifier = Modifier
                    .border(1.dp, NanzMusifyCrimson)
                    .background(NanzMusifyCrimson.copy(alpha = 0.15f))
                    .clickable(onClick = onPlayDownloads)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
            ) {
                Text(stringResource(R.string.offline_play_mode), style = MaterialTheme.typography.labelMedium, color = NanzMusifyTextPrimary)
            }
        }
    }
}

@Composable
internal fun NewPlaylistDialog(
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NanzMusifyElevated,
        title = { Text(stringResource(R.string.new_playlist_title), style = MaterialTheme.typography.labelMedium, color = NanzMusifyCrimson) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                singleLine = true,
                placeholder = {
                    Text(stringResource(R.string.new_playlist_hint), style = MaterialTheme.typography.bodySmall, color = NanzMusifyTextMuted)
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NanzMusifyCrimson,
                    unfocusedBorderColor = NanzMusifyLine,
                    cursorColor = NanzMusifyTextPrimary,
                    focusedTextColor = NanzMusifyTextPrimary,
                    unfocusedTextColor = NanzMusifyTextPrimary,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onCreate(name.trim()) }) {
                Text(stringResource(R.string.action_create), style = MaterialTheme.typography.labelMedium, color = NanzMusifyCrimson)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.action_cancel), style = MaterialTheme.typography.labelMedium, color = NanzMusifyTextSecondary)
            }
        },
    )
}
